import torch
from torch.utils.data import DataLoader
from models.pd_glcst import ConvSpaformer

# Load trained model
model = ConvSpaformer()
model.load_state_dict(torch.load("checkpoints/pd_glcst.pth"))
model.eval()

# Load test dataset
test_dataset = []  # Load dataset here
test_loader = DataLoader(test_dataset, batch_size=16)

# Evaluate model
correct, total = 0, 0
with torch.no_grad():
    for images, labels in test_loader:
        outputs = model(images)
        _, predicted = torch.max(outputs, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

print(f'Accuracy: {100 * correct / total:.2f}%')
