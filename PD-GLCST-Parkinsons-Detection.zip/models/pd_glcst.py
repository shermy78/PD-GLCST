import torch
import torch.nn as nn

class ConvSpaformer(nn.Module):
    def __init__(self):
        super(ConvSpaformer, self).__init__()
        self.conv = nn.Conv2d(3, 64, kernel_size=3, padding=1)
        self.sparse_attention = nn.MultiheadAttention(embed_dim=64, num_heads=8)
        self.fc = nn.Linear(64, 2)  # Binary classification (PD vs. Healthy)

    def forward(self, x):
        x = self.conv(x)
        x = x.flatten(start_dim=1)  # Convert to sequence
        attn_output, _ = self.sparse_attention(x, x, x)
        x = self.fc(attn_output)
        return x
