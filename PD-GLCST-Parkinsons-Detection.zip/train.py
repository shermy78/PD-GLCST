import torch
import torch.optim as optim
from torch.utils.data import DataLoader
from models.pd_glcst import ConvSpaformer

# Load dataset
train_dataset = [] # Load dataset here
train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)

# Initialize model
model = ConvSpaformer()
optimizer = optim.Adam(model.parameters(), lr=0.001, weight_decay=0.0001)
criterion = torch.nn.CrossEntropyLoss()

# Training loop
for epoch in range(100):
    for images, labels in train_loader:
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
    print(f'Epoch [{epoch+1}/100], Loss: {loss.item():.4f}')
